MantisBT scripts
================

- _send_emails.php_ :
    Allows sending bug mails asynchronously
